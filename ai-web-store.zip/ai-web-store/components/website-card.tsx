import Image from 'next/image'
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ExternalLink, Info } from 'lucide-react'
import { WebsiteModal } from './website-modal'

interface Website {
  id: string
  name: string
  description: string
  imageUrl: string
  url: string
  category: string
  pricing: string
}

export function WebsiteCard({ website }: { website: Website }) {
  return (
    <Card className="flex flex-col h-full transition-all duration-300 ease-in-out">
      <CardHeader>
        <div className="relative w-full h-48 mb-4">
          <Image
            src={website.imageUrl || '/placeholder.svg?height=400&width=600'}
            alt={website.name}
            fill
            className="object-cover rounded-md transition-all duration-300 ease-in-out"
          />
        </div>
        <CardTitle className="transition-all duration-300 ease-in-out">{website.name}</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow">
        <div className="flex justify-between items-center mb-2">
          <Badge variant="secondary" className="transition-all duration-300 ease-in-out">{website.category}</Badge>
          <Badge 
            variant="outline" 
            className={`transition-all duration-300 ease-in-out ${
              website.pricing === 'Free' 
                ? 'bg-green-500 hover:bg-green-600' 
                : website.pricing === 'Freemium'
                ? 'bg-yellow-500 hover:bg-yellow-600'
                : 'bg-red-500 hover:bg-red-600'
            } text-white`}
          >
            {website.pricing}
          </Badge>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col space-y-2">
        <WebsiteModal website={website}>
          <Button variant="outline" className="w-full transition-all duration-300 ease-in-out">
            <Info className="w-4 h-4 mr-2" /> View More
          </Button>
        </WebsiteModal>
        <Button asChild className="w-full transition-all duration-300 ease-in-out">
          <a href={website.url} target="_blank" rel="noopener noreferrer">
            Visit Website <ExternalLink className="ml-2 h-4 w-4" />
          </a>
        </Button>
      </CardFooter>
    </Card>
  )
}

