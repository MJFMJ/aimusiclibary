'use client'

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import Image from 'next/image'
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink } from 'lucide-react'

interface Website {
  id: string
  name: string
  description: string
  imageUrl: string
  url: string
  category: string
  pricing: string
}

export function WebsiteModal({ website, children }: { website: Website; children: React.ReactNode }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] transition-all duration-300 ease-in-out">
        <DialogHeader>
          <DialogTitle className="transition-colors duration-300">
            {website.name}
          </DialogTitle>
          <DialogDescription className="transition-colors duration-300 flex justify-between items-center">
            <Badge variant="secondary">{website.category}</Badge>
            <Badge 
              variant="outline" 
              className={`transition-colors duration-300 ${
                website.pricing === 'Free' 
                  ? 'bg-green-500 hover:bg-green-600' 
                  : website.pricing === 'Freemium'
                  ? 'bg-yellow-500 hover:bg-yellow-600'
                  : 'bg-red-500 hover:bg-red-600'
              } text-white`}
            >
              {website.pricing}
            </Badge>
          </DialogDescription>
        </DialogHeader>
        <div className="relative w-full h-48 mb-4">
          <Image
            src={website.imageUrl || '/placeholder.svg?height=400&width=600'}
            alt={website.name}
            fill
            className="object-cover rounded-md transition-all duration-300 ease-in-out"
          />
        </div>
        <p className="text-sm text-muted-foreground mb-4 transition-colors duration-300">{website.description}</p>
        <Button asChild className="w-full transition-all duration-300 ease-in-out">
          <a href={website.url} target="_blank" rel="noopener noreferrer">
            Visit Website <ExternalLink className="ml-2 h-4 w-4" />
          </a>
        </Button>
      </DialogContent>
    </Dialog>
  )
}

