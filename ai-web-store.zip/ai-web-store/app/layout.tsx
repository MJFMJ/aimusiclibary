import '@/styles/globals.css'
import { Inter } from 'next/font/google'
import { MainNav } from '@/components/main-nav'
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'AI Music Tool Library',
  description: 'Discover cutting-edge AI music generation websites and tools',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.className} transition-colors duration-300 ease-in-out`}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <header className="border-b transition-colors duration-300">
            <div className="container mx-auto px-4 py-2">
              <MainNav />
            </div>
          </header>
          <main className="min-h-screen bg-background transition-colors duration-300">
            {children}
          </main>
        </ThemeProvider>
      </body>
    </html>
  )
}

