export const websiteData = [
  {
    id: '1',
    name: 'Udio',
    description: 'AI Song Creator that helps creating Songs with advanced AI technology.',
    imageUrl: 'https://deltl.de/wp-content/uploads/2024/04/Udio.png',
    url: 'https://www.udio.com/home',
    category: 'AI Song Generation',
    pricing: 'Freemium'
  },
  {
    id: '2',
    name: 'AIVA',
    description: 'AI composer that creates original music for films, commercials, games & more.',
    imageUrl: 'https://yt3.googleusercontent.com/X-Nns_Vc9eol4nMrV_3vvPxn8v1f-MJ8GGHqu-HzUjwD4m-dFshkTrObWmOFi-nP4r3e2zaN4ac=s900-c-k-c0x00ffffff-no-rj',
    url: 'https://www.aiva.ai/',
    category: 'AI Composition',
    pricing: 'Freemium'
  },
  {
    id: '3',
    name: 'Amper Music',
    description: 'AI-powered music composition platform for content creators and businesses.',
    imageUrl: 'https://cdn.asp.events/CLIENT_Media_Bu_282F8449_9953_6F53_6E524AED3459B222/sites/MediaProduction2020/media/libraries/exhibitor-news/1335378_amper_541225.jpg',
    url: 'https://www.ampermusic.com/',
    category: 'AI Composition',
    pricing: 'Paid'
  },
  {
    id: '4',
    name: 'Boomy',
    description: 'Create original songs in seconds, even if you\'ve never made music before.',
    imageUrl: 'https://waildworld.com/assets/components/phpthumbof/cache/265.65027b08a90549322d0a72caea8861bd.jpg',
    url: 'https://boomy.com/',
    category: 'AI Song Generation',
    pricing: 'Freemium'
  },
  {
    id: '5',
    name: 'Melodrive',
    description: 'AI-driven adaptive music engine for games and interactive media.',
    imageUrl: 'https://assetstorev1-prd-cdn.unity3d.com/key-image/a23d0415-98e8-46e4-803a-9f1252daf047.png',
    url: 'https://melodrive.com/',
    category: 'Adaptive Music',
    pricing: 'Paid'
  },
  {
    id: '6',
    name: 'Endel',
    description: 'Personalized soundscapes to help you focus, relax, and sleep.',
    imageUrl: 'https://endel.io/pages/index/opengraph.jpg',
    url: 'https://endel.io/',
    category: 'Adaptive Soundscapes',
    pricing: 'Freemium'
  }
];

export const freeWebsiteData = [
  {
    id: 'f1',
    name: 'Mubert',
    description: 'AI-powered music generator for content creators, offering royalty-free tracks.',
    imageUrl: 'https://ml.globenewswire.com/Resource/Download/18405368-1bf4-4c22-a1e0-65634cbbc977',
    url: 'https://mubert.com/',
    category: 'AI Music Generation',
    pricing: 'Free'
  },
  {
    id: 'f2',
    name: 'Beatoven.ai',
    description: 'Create unique royalty-free music for your videos using AI.',
    imageUrl: 'https://smartaifinds.com/wp-content/uploads/2023/10/Screenshot-2023-10-06-at-02.44.48-1200x900.webp',
    url: 'https://www.beatoven.ai/',
    category: 'AI Composition',
    pricing: 'Free'
  },
  {
    id: 'f3',
    name: 'Soundraw',
    description: 'AI music generator that creates original tracks based on your preferences.',
    imageUrl: 'https://cdn.prod.website-files.com/63994dae1033718bee6949ce/639bb00bc658fc0724b93967_soundraw_ogp_EN.png',
    url: 'https://soundraw.io/',
    category: 'AI Music Generation',
    pricing: 'Free'
  },
  {
    id: 'f4',
    name: 'Ecrett Music',
    description: 'AI-powered background music generator for videos and content.',
    imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRKeOA9tRMhogjG9_muXXqFxR4cvgcjNR2Msg&s',
    url: 'https://ecrettmusic.com/',
    category: 'AI Background Music',
    pricing: 'Free'
  },
  {
    id: 'f5',
    name: 'Musico',
    description: 'AI-driven music creation tool for interactive music experiences.',
    imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRtlk_cMpqrXG8fb0WufwPjk9_m8rsahmuqw&s',
    url: 'https://www.musi-co.com/',
    category: 'Interactive AI Music',
    pricing: 'Free'
  }
];

